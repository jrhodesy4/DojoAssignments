from __future__ import unicode_literals

from django.apps import AppConfig


class RealAppConfig(AppConfig):
    name = 'real_app'
