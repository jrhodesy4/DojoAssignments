from __future__ import unicode_literals

from django.apps import AppConfig


class NinGoldConfig(AppConfig):
    name = 'nin_gold'
