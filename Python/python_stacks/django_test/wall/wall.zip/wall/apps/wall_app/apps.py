from __future__ import unicode_literals

from django.apps import AppConfig


class WallAppConfig(AppConfig):
    name = 'wall_app'
